export const data = [
  {
    name: "Какаду",
    url: "/Cockatoo.1.arp.500pix.jpg",
  },
  {
    name: "Ара",
    url: "/Parrot.red.macaw.1.arp.750pix.jpg",
  },
  {
    name: "Какапо",
    url: "/Sirocco_full_length_portrait.jpg",
  },
  {
    name: "Жако",
    url: "/Psittacus_erithacus_qtl1.jpg",
  },
];
