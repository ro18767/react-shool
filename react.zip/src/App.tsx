import { Task1 } from "./Task1";
import { Task2 } from "./Task2";

export function App() {
  return (
    <div>
        <Task1 />
        <Task2 />
    </div>
  );
}
