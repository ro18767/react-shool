import { raceData } from "./raceData";
import racerURL from "./assets/turtle.png";
import finishURL from "./assets/finish.png";

export const Race = () => {
  return (
    <ul>
      <li>winner: {raceData.winer}</li>
      {/* <li>p1: {raceData.p1}</li> */}
      {/* <li>p2: {raceData.p2}</li> */}
      <div style={{
        
        display: "grid",
        gridTemplateAreas: `'p1 fin' 'p2 fin'`,
      }}>
        <div
          style={{
            gridArea: 'p1',
            display: "grid",
            gridTemplateColumns: `${raceData.p1 / 100}fr auto`,
          }}
        >
          <i />
          <div
            style={{
              display: "inline-flex",
              flexDirection: "column",
              width: "50px",
            }}
          >
            <img style={{}} src={racerURL} alt="racer" />
            <span>p1</span>
          </div>
        </div>

        <div
          style={{
            gridArea: 'p2',
            display: "grid",
            gridTemplateColumns: `${raceData.p2 / 100}fr auto`,
          }}
        >
          <i />
          <div
            style={{
              display: "inline-flex",
              flexDirection: "column",
              width: "50px",
            }}
          >
            <img style={{}} src={racerURL} alt="racer" />
            <span>p2</span>
          </div>
        </div>
        <img style={{
            gridArea: 'fin',
        }} src={finishURL} alt="" />
      </div>
    </ul>
  );
};
