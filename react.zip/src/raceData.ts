


export const raceData = {
  p1: 0,
  p2: 0,
  winer: "waiting..",
};

const interval = setInterval(() => {
  raceData.p1 += Math.random() * 5;
  raceData.p2 += Math.random() * 5;

  if (Math.max(raceData.p1, raceData.p2) >= 100) {
    clearInterval(interval);

    raceData.winer = "p1";
    if (raceData.p2 > raceData.p1) {
      raceData.winer = "p2";
    }
  }
}, 100);
