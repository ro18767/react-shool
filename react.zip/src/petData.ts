import petURL from "./assets/pet.png";
import graveURL from "./assets/grave.png";

export const petData = {
  name: "Одди",
  breed: "Джек Рассел терьер",
  age: 5,
  img_src: petURL,
};



const interval = setInterval(() => {
    petData.age += 1;
    console.log(`petData.age: ${petData.age}`);
  
    if (petData.age >= 8) {
      clearInterval(interval);
      petData.img_src = graveURL;
    }
  }, 2000);