import React, { Component } from "react";
import ReactDOM from "react-dom/client";
import "./index.css";
import { Pet } from "./Pet";
import { Race } from "./race";

function animate() {
  requestAnimationFrame(animate);

  ReactDOM.createRoot(document.getElementById("root")!).render(
    <React.StrictMode>
      <div>
        <Pet />
        <Race />
      </div>
    </React.StrictMode>,
  );
}
animate();
